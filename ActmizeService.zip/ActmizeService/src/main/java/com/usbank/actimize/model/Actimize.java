package com.usbank.actimize.model;

public class Actimize {

	public String getActionCode() {
		return actionCode;
	}
	public void setActionCode(String actionCode) {
		this.actionCode = actionCode;
	}
	public String getStatusCode() {
		return statusCode;
	}
	public void setStatusCode(String statusCode) {
		this.statusCode = statusCode;
	}
	public String getChannelIdentifier() {
		return channelIdentifier;
	}
	public void setChannelIdentifier(String channelIdentifier) {
		this.channelIdentifier = channelIdentifier;
	}
	public String getTransactionTrype() {
		return transactionTrype;
	}
	public void setTransactionTrype(String transactionTrype) {
		this.transactionTrype = transactionTrype;
	}
	public Double getPaymentAmount() {
		return paymentAmount;
	}
	public void setPaymentAmount(Double paymentAmount) {
		this.paymentAmount = paymentAmount;
	}
	public String getPaymentIdentifier() {
		return paymentIdentifier;
	}
	public void setPaymentIdentifier(String paymentIdentifier) {
		this.paymentIdentifier = paymentIdentifier;
	}
	public String getTransmitDeviceId() {
		return transmitDeviceId;
	}
	public void setTransmitDeviceId(String transmitDeviceId) {
		this.transmitDeviceId = transmitDeviceId;
	}
	public String getWebsessionKey() {
		return websessionKey;
	}
	public void setWebsessionKey(String websessionKey) {
		this.websessionKey = websessionKey;
	}
	public String getTransmitSessionID() {
		return transmitSessionID;
	}
	public void setTransmitSessionID(String transmitSessionID) {
		this.transmitSessionID = transmitSessionID;
	}
	public String getUserID() {
		return userID;
	}
	public void setUserID(String userID) {
		this.userID = userID;
	}
	public String getUserName() {
		return userName;
	}
	public void setUserName(String userName) {
		this.userName = userName;
	}
	public String getMobileNumber() {
		return mobileNumber;
	}
	public void setMobileNumber(String mobileNumber) {
		this.mobileNumber = mobileNumber;
	}
	public String getMobile() {
		return mobile;
	}
	public void setMobile(String mobile) {
		this.mobile = mobile;
	}
	public String getOS() {
		return OS;
	}
	public void setOS(String oS) {
		OS = oS;
	}
	public String getAnalyticsScore() {
		return analyticsScore;
	}
	public void setAnalyticsScore(String analyticsScore) {
		this.analyticsScore = analyticsScore;
	}
	public String getTrxRiskScore() {
		return trxRiskScore;
	}
	public void setTrxRiskScore(String trxRiskScore) {
		this.trxRiskScore = trxRiskScore;
	}
	private String actionCode;
	private String statusCode;
	private String channelIdentifier;
	private String transactionTrype;
	private Double paymentAmount;
	private String paymentIdentifier;
	private String transmitDeviceId;
	private String websessionKey;
	private String transmitSessionID;
	private String userID;
	private String userName;
	private String mobileNumber;
	private String mobile;
	private String OS;
	private String analyticsScore;
	private String trxRiskScore;

}
