package com.usbank.actimize;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ActmizeServiceApplication {

	public static void main(String[] args) {
		SpringApplication.run(ActmizeServiceApplication.class, args);
	}

}
