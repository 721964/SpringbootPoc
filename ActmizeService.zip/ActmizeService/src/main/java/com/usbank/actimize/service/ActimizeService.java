package com.usbank.actimize.service;

import org.springframework.boot.json.JsonParseException;

public interface ActimizeService {

	String actimizereq(String ActimizeReq) throws JsonParseException;
}
