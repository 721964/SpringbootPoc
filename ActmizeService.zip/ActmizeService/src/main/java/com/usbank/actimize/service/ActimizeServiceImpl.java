package com.usbank.actimize.service;

import org.springframework.boot.json.JsonParseException;
import org.springframework.stereotype.Service;

@Service
public class ActimizeServiceImpl implements ActimizeService{

	@Override
	public String actimizereq(String ActimizeReq) throws JsonParseException {
		// TODO Auto-generated method stub
		return null;
	}

}
